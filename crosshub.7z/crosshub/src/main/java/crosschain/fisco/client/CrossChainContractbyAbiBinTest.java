// Implements deployment, invocation, and interaction with a cross-chain contract
// using ABI and binary files, and integrates with the hub for cross-chain operations.

package crosschain.fisco.client;


import crosschain.fabric.gateway_connect.HubCrossChainGatewayTest;

import org.fisco.bcos.sdk.BcosSDK;

import org.fisco.bcos.sdk.abi.ABICodecException;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;

import org.fisco.bcos.sdk.transaction.manager.AssembleTransactionProcessor;
import org.fisco.bcos.sdk.transaction.manager.TransactionProcessorFactory;
import org.fisco.bcos.sdk.transaction.model.dto.TransactionResponse;
import org.fisco.bcos.sdk.transaction.model.exception.TransactionBaseException;

import org.hyperledger.fabric.gateway.ContractException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.ArrayList;
import java.util.List;

import java.util.concurrent.TimeoutException;

// Implements the deployment and invocation of the contract
// ABI and contract deployment calls have been updated to the latest version

public class CrossChainContractbyAbiBinTest {

    static Logger logger= LoggerFactory.getLogger(CrossChainContractbyAbiBinTest.class);

    private BcosSDK bcosSDK;
    private Client client;
    private CryptoKeyPair cryptoKeyPair;
    private String abi= "[{\"inputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"constructor\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"address\",\"name\":\"from\",\"type\":\"address\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"value\",\"type\":\"uint256\"}],\"name\":\"AssetBurnEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"address\",\"name\":\"from\",\"type\":\"address\"},{\"indexed\":false,\"internalType\":\"address\",\"name\":\"to\",\"type\":\"address\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"value\",\"type\":\"uint256\"}],\"name\":\"AssetMintEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"value\",\"type\":\"uint256\"}],\"name\":\"approveEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"string\",\"name\":\"cross_TxNo\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"uint8\",\"name\":\"txType\",\"type\":\"uint8\"}],\"name\":\"sendAckedEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"string\",\"name\":\"cross_TxNo\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"uint8\",\"name\":\"txType\",\"type\":\"uint8\"}],\"name\":\"sendTxEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"string\",\"name\":\"chain_Code\",\"type\":\"string\"}],\"name\":\"setChainCodeEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"address\",\"name\":\"gateway_Address\",\"type\":\"address\"}],\"name\":\"setGatewayEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"string\",\"name\":\"cross_TxNo\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"uint8\",\"name\":\"txType\",\"type\":\"uint8\"}],\"name\":\"startTxEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"address\",\"name\":\"to\",\"type\":\"address\"}],\"name\":\"takeOutEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"value\",\"type\":\"uint256\"}],\"name\":\"transferEvent\",\"type\":\"event\"},{\"inputs\":[{\"internalType\":\"string\",\"name\":\"funcn\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"key\",\"type\":\"string\"}],\"name\":\"createCrossChainRead\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"string\",\"name\":\"funcn\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"key\",\"type\":\"string\"},{\"internalType\":\"uint8\",\"name\":\"value\",\"type\":\"uint8\"}],\"name\":\"createCrossChainWrite\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"value1\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"}]";
    //console :"0x05f2b7ddbd8db80351b38965cbf538c9669e205c"
    private  String crossChainContractAddress="0x1c1c86def5350aaa3691af7a1be0dd123f584d37";

    AssembleTransactionProcessor transactionProcessor;
    private static HubCrossChainGatewayTest hubCrossChainGateway;

    public static void main(String[] args) throws Exception {
        CrossChainContractbyAbiBinTest crossChainContractbyAbiBin=new CrossChainContractbyAbiBinTest();
        crossChainContractbyAbiBin.initialize();
        hubCrossChainGateway=new HubCrossChainGatewayTest();
        hubCrossChainGateway.connect("crossChainContract");

        crossChainContractbyAbiBin.crossChainWriteTest();

    }
    public void initialize() throws Exception{
        @SuppressWarnings("resource")
        ApplicationContext context=new ClassPathXmlApplicationContext("classpath:applicationContext.xml");

        // Initialize the BcosSDK object
        bcosSDK=context.getBean(BcosSDK.class);

        // Retrieve the Client object with the specified group ID of 1
        client=bcosSDK.getClient(1);

        // Construct an AssembleTransactionProcessor object by passing the client object, CryptoKeyPair object,
// and the paths to the ABI and binary files. Ensure that the ABI and binary files are copied to the
// defined folder from the previous step.

        cryptoKeyPair=client.getCryptoSuite().getCryptoKeyPair();

        // Deploy, transact, and query the contract based on ABI and binary files; deployment requires the binary file,
        // while transactions and queries can use an empty binary string ("").

        transactionProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(client, cryptoKeyPair, "src/main/resources/abi/", "src/main/resources/bin/");

    }

    // Deployment only needs to be done once.
    public TransactionResponse deployCrossChainContract(String contractName) throws Exception {

        // Deploy, transact, and query contracts based on ABI and binary files; deployment requires the binary file, while transaction and query operations can use an empty string for the binary.
        transactionProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(client, cryptoKeyPair, "src/main/resources/abi/", "src/main/resources/bin/");

        // Deploy the HelloWorld contract, with the first parameter being the contract name and the second parameter being a list of constructor arguments (of type List<Object>).
        TransactionResponse response = transactionProcessor.deployByContractLoader(contractName, new ArrayList<>());
         crossChainContractAddress=response.getContractAddress();
        //<<<<<<<<<<<<CrossChainContractAddress>>>>>>>>>>::::0xc0f18d06c4b7b34ff64b2abf84a6754139107ed9
        System.out.println("<<<<<<<<<<<<contractAddress>>>>>>>>>>::::"+crossChainContractAddress);
        return response;
    }

    public void crossChainWriteTest() throws ABICodecException, TransactionBaseException, InterruptedException, TimeoutException, ContractException {
        // After calling, directly invoke the hub
        // Call the FISCO contract
        // Create parameters for the transaction function call, with one argument passed in this case

        List<Object> params = new ArrayList<>();
        params.add("crossChainWrite");
        params.add("a");
        params.add("100");

        // Call the HelloWorld contract at the address helloWorldAddress, invoking the function named 'set' with parameters of type params
        TransactionResponse transactionResponse = transactionProcessor.sendTransactionAndGetResponseByContractLoader("CrossChainContractTest", crossChainContractAddress, "createCrossChainWrite", params);

        // Call the hub
        String result = hubCrossChainGateway.testCrossChainWrite("a","100");
        System.out.println("===================fiscoHub======================");
        System.out.println(result);
        System.out.println("===================fiscoHub======================");
    }
    public void crossChainReadTest() throws ABICodecException, TransactionBaseException, InterruptedException, TimeoutException, ContractException {

        // After calling, directly invoke the hub
        // Call the FISCO contract
        // Create parameters for the transaction function call, passing a single argument here

        List<Object> params = new ArrayList<>();
        params.add("crossChainRead");
        params.add("a");

        // Call the HelloWorld contract with address helloWorldAddress
        // Function name: 'set', Function parameters: params
        TransactionResponse transactionResponse = transactionProcessor.sendTransactionAndGetResponseByContractLoader("CrossChainContractTest", crossChainContractAddress, "createCrossChaiRead", params);

        // Call the hub

        String result = hubCrossChainGateway.testCrossChainRead("a");
        System.out.println("===================fiscoHub======================");
        System.out.println(result);
        System.out.println("===================fiscoHub======================");
    }

}
