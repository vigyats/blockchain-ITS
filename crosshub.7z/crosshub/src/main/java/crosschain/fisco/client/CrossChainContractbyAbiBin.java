//The code handles and processes cross-chain transactions and acknowledgments,
// interacting with other hubs and contracts based on transaction type.

package crosschain.fisco.client;


import crosschain.fabric.contract.HubCrossChainContract;
import crosschain.fabric.contract.entity.CrossChainObj;
import crosschain.fabric.gateway_connect.HubCrossChainGateway;
import crosschain.fisco.client.entity.*;
import org.fisco.bcos.sdk.BcosSDK;
import org.fisco.bcos.sdk.abi.ABICodec;
import org.fisco.bcos.sdk.abi.ABICodecException;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.eventsub.*;
import org.fisco.bcos.sdk.model.EventLog;
import org.fisco.bcos.sdk.model.TransactionReceipt;
import org.fisco.bcos.sdk.transaction.manager.AssembleTransactionProcessor;
import org.fisco.bcos.sdk.transaction.manager.TransactionProcessorFactory;
import org.fisco.bcos.sdk.transaction.model.dto.TransactionResponse;
import org.fisco.bcos.sdk.transaction.model.exception.TransactionBaseException;
import org.fisco.bcos.sdk.transaction.model.exception.TransactionException;
import org.hyperledger.fabric.gateway.ContractException;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeoutException;

// Implements contract deployment and invocation, with ABI and contract deployment calls updated to the latest version.

public class CrossChainContractbyAbiBin {

    static Logger logger= LoggerFactory.getLogger(CrossChainContractbyAbiBin.class);

    private BcosSDK bcosSDK;
    private Client client;
    private CryptoKeyPair cryptoKeyPair;
    private String abi= "[{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"address\",\"name\":\"from\",\"type\":\"address\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"value\",\"type\":\"uint256\"}],\"name\":\"AssetBurnEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"address\",\"name\":\"from\",\"type\":\"address\"},{\"indexed\":false,\"internalType\":\"address\",\"name\":\"to\",\"type\":\"address\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"value\",\"type\":\"uint256\"}],\"name\":\"AssetMintEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"value\",\"type\":\"uint256\"}],\"name\":\"approveEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"string\",\"name\":\"cross_TxNo\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"uint8\",\"name\":\"txType\",\"type\":\"uint8\"}],\"name\":\"sendAckedEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"string\",\"name\":\"cross_TxNo\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"uint8\",\"name\":\"txType\",\"type\":\"uint8\"}],\"name\":\"sendTxEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"string\",\"name\":\"chain_Code\",\"type\":\"string\"}],\"name\":\"setChainCodeEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"address\",\"name\":\"gateway_Address\",\"type\":\"address\"}],\"name\":\"setGatewayEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"string\",\"name\":\"cross_TxNo\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"uint8\",\"name\":\"txType\",\"type\":\"uint8\"}],\"name\":\"startTxEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"address\",\"name\":\"to\",\"type\":\"address\"}],\"name\":\"takeOutEvent\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":false,\"internalType\":\"string\",\"name\":\"operation\",\"type\":\"string\"},{\"indexed\":false,\"internalType\":\"uint256\",\"name\":\"value\",\"type\":\"uint256\"}],\"name\":\"transferEvent\",\"type\":\"event\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"from\",\"type\":\"address\"},{\"internalType\":\"address\",\"name\":\"to\",\"type\":\"address\"},{\"internalType\":\"uint256\",\"name\":\"value\",\"type\":\"uint256\"}],\"name\":\"approve\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"addr\",\"type\":\"address\"}],\"name\":\"balanceOf\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"owner\",\"type\":\"address\"},{\"internalType\":\"address\",\"name\":\"spender\",\"type\":\"address\"}],\"name\":\"getAllowance\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"string\",\"name\":\"crossTxNo\",\"type\":\"string\"}],\"name\":\"getCrossTx\",\"outputs\":[{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"},{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"},{\"internalType\":\"bytes\",\"name\":\"\",\"type\":\"bytes\"},{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"string\",\"name\":\"crossTxNo\",\"type\":\"string\"}],\"name\":\"getCrossTxSendAndAckProof\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"},{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"},{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"},{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"},{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"},{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"getVersion\",\"outputs\":[{\"internalType\":\"string\",\"name\":\"\",\"type\":\"string\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"crossChainAdd\",\"type\":\"address\"}],\"name\":\"initialize\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"string\",\"name\":\"crossTxNo\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"txResult\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"version\",\"type\":\"string\"},{\"internalType\":\"bytes\",\"name\":\"proof\",\"type\":\"bytes\"}],\"name\":\"sendAcked\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"string\",\"name\":\"srcBid\",\"type\":\"string\"},{\"internalType\":\"address payable\",\"name\":\"destAddress\",\"type\":\"address\"},{\"internalType\":\"string\",\"name\":\"srcChainCode\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"destChainCode\",\"type\":\"string\"},{\"internalType\":\"uint8\",\"name\":\"txType\",\"type\":\"uint8\"},{\"internalType\":\"string\",\"name\":\"crossTxNo\",\"type\":\"string\"},{\"internalType\":\"bytes\",\"name\":\"payload\",\"type\":\"bytes\"},{\"internalType\":\"string\",\"name\":\"extension\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"remark\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"version\",\"type\":\"string\"},{\"internalType\":\"bytes\",\"name\":\"proof\",\"type\":\"bytes\"}],\"name\":\"sendTx\",\"outputs\":[],\"stateMutability\":\"payable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"string\",\"name\":\"chaincode\",\"type\":\"string\"}],\"name\":\"setChainCode\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"gatewayAddress\",\"type\":\"address\"}],\"name\":\"setGateway\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"srcAddress\",\"type\":\"address\"},{\"internalType\":\"string\",\"name\":\"destBid\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"srcChainCode\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"destChainCode\",\"type\":\"string\"},{\"internalType\":\"uint8\",\"name\":\"txType\",\"type\":\"uint8\"},{\"internalType\":\"bytes\",\"name\":\"payload\",\"type\":\"bytes\"},{\"internalType\":\"string\",\"name\":\"extension\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"remark\",\"type\":\"string\"},{\"internalType\":\"string\",\"name\":\"version\",\"type\":\"string\"}],\"name\":\"startTx\",\"outputs\":[],\"stateMutability\":\"payable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"string\",\"name\":\"crossTxNo\",\"type\":\"string\"},{\"internalType\":\"address payable\",\"name\":\"to\",\"type\":\"address\"}],\"name\":\"takeOut\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"to\",\"type\":\"address\"},{\"internalType\":\"uint256\",\"name\":\"value\",\"type\":\"uint256\"}],\"name\":\"transfer\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"}]";
    //console :"0x05f2b7ddbd8db80351b38965cbf538c9669e205c"
    private  String crossChainContractAddress="0xb04b655e78fed67925c18d0705796ceb58ff28bb";

    AssembleTransactionProcessor transactionProcessor;
    private static HubCrossChainGateway hubCrossChainGateway;

    public static void main(String[] args) throws Exception {
        CrossChainContractbyAbiBin crossChainContractbyAbiBin=new CrossChainContractbyAbiBin();
        crossChainContractbyAbiBin.initialize();
        crossChainContractbyAbiBin.getEvents("1","latest");
        hubCrossChainGateway=new HubCrossChainGateway();

    }
    public void initialize() throws Exception{
        @SuppressWarnings("resource")
        ApplicationContext context=new ClassPathXmlApplicationContext("classpath:applicationContext.xml");

        // Initializes the BcosSDK object
        bcosSDK=context.getBean(BcosSDK.class);

        // Retrieves the Client object with the specified group ID of 1

        client=bcosSDK.getClient(1);

        // Constructs the AssembleTransactionProcessor object by passing in the client object,
        // CryptoKeyPair object, and paths to the ABI and binary files;
        // ensure the ABI and binary files are copied to the defined folders
        cryptoKeyPair=client.getCryptoSuite().getCryptoKeyPair();

        // Deploy, transact, and query contracts based on ABI and binary files; deployment requires the binary file, while transactions and queries can use an empty binary string ("").
        transactionProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(client, cryptoKeyPair, "src/main/resources/abi/", "src/main/resources/bin/");

    }

    // Deployment is needed only once.
    public TransactionResponse deployCrossChainContract(String contractName) throws Exception {

        // Deploy, transact, and query contracts based on ABI and binary files; deployment requires the binary file, while transaction and query operations can use an empty string for the binary.

        transactionProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(client, cryptoKeyPair, "src/main/resources/abi/", "src/main/resources/bin/");

        // Deploy the HelloWorld contract. The first parameter is the contract name, and the second parameter is a list of constructor arguments of type List<Object>.
        TransactionResponse response = transactionProcessor.deployByContractLoader(contractName, new ArrayList<>());
         crossChainContractAddress=response.getContractAddress();
        //<<<<<<<<<<<<CrossChainContractAddress>>>>>>>>>>::::0xc0f18d06c4b7b34ff64b2abf84a6754139107ed9
        System.out.println("<<<<<<<<<<<<contractAddress>>>>>>>>>>::::"+crossChainContractAddress);
        return response;
    }

    // Generate an account
//    public void createAccount(){
//        // Create a non-GM type CryptoSuite
//        CryptoSuite cryptoSuite = new CryptoSuite(CryptoType.ECDSA_TYPE);
//       // Generate a random non-GM public-private key pair
//        CryptoKeyPair cryptoKeyPair = cryptoSuite.createKeyPair();
//       // Retrieve the account address
//        String accountAddress = cryptoKeyPair.getAddress();
//    }

    public void getEvents(String fromBlock,String toBlock){
        // Contract event pushing
// 1. Register request
// 2. Node response
// 3. Event log data push
// 1. Callback all/latest on-chain events to the client

// Parameter settings

        EventLogParams params1=new EventLogParams();
        // Parameter settings
        params1.setFromBlock(fromBlock);
        // Set toBlock to "latest" to process up to the latest block and continue waiting for new blocks
        params1.setToBlock(toBlock);

        // Set addresses to an empty array to match all contract addresses and callback all events from the blockchain to the client
        params1.setAddresses(new ArrayList<String>());
        // Set topics to an empty array to match all events
        params1.setTopics(new ArrayList<Object>());

        // Callback function
        class SubscribeCallback implements EventCallback {
            public transient Semaphore semaphore = new Semaphore(1, true);

            SubscribeCallback() {
                try {
                    semaphore.acquire(1);
                } catch (InterruptedException e) {
                    logger.error("error :", e);
                    Thread.currentThread().interrupt();
                }
            }

            @Override
            public void onReceiveLog(int status, List<EventLog> logs) {
                System.out.println("+++++++++++++++++++++++++++++Start executing the onReceiveLog function+++++++++++++++++++++++++++++++");
                Assert.assertEquals(status, 0);
                String str = "status in onReceiveLog : " + status;
                logger.debug(str);
                System.out.println("+++++++++++++++++++++++++++++"+str+"+++++++++++++++++++++++++++++++");
                semaphore.release();
                // decode event

                if (logs != null) {
                    for (EventLog log : logs) {
                        logger.debug(
                                " blockNumber:"
                                        + log.getBlockNumber()
                                        + ",txIndex:"
                                        + log.getTransactionIndex()
                                        + " data:"
                                        + log.getData()
                                        + " topics: "+log.getTopics());
                        ABICodec abiCodec = new ABICodec(client.getCryptoSuite());

                        System.out.println("__________________________");
                        System.out.println(  " --blockNumber:"
                                + log.getBlockNumber()
                                + ",--txIndex:"
                                + log.getTransactionIndex()
                                + "--- data:"
                                + log.getData()
                                + ",--topics: "+log.getTopics());

                        try {
                            //todo：Need to listen for all types of cross-chain events
                            List<Object> list = abiCodec.decodeEvent(abi, "startTxEvent", log);  //
//                            List<Object> list = abiCodec.decodeEventByTopic(abi,log.getTopics().get(0), log);  //
                            logger.debug("decode event log content, " + list);
                            System.out.println("===========list："+list);

                            //In the contract：emit sendTxEvent("sendTx", crossTxNo, txType);   Emit contract events
                            //_crossTxNo：It is pieced together  srcChainCodestChainCodede：Unknown (but it is the same data)
                            String _crossTxNo= (String) list.get(1);
                            BigInteger _crossTxType = (BigInteger) list.get(2);

                            BigInteger _ledgerSeq=log.getBlockNumber();
                            String _txHash =log.getTransactionHash();

                            if(list.get(0).equals("startTx")){
                                // User sends cross-chain transaction event, gateway node forwards the cross-chain transaction.
                                System.out.println("startTx事件");
                                _startTx(_crossTxNo,_crossTxType,_ledgerSeq,_txHash);
                            }else if(list.get(0).equals("sendTx")){
                                // The cross-chain transaction forwarded by the gateway node is successfully on-chain and needs to send an acknowledgment back to the source chain
                                System.out.println("sendTx事件");
                                _sendTx(_crossTxNo,_ledgerSeq,_txHash);
                            }
                            else if(list.get(0).equals("sendAcked")){
                                // The acknowledgment sent by the gateway node is successfully on-chain and needs to send an acknowledgment back to the destination chain.
                                System.out.println("sendAcked事件");
                                _sendAcked(_crossTxNo,_ledgerSeq,_txHash);
                            }
                            else{
                                System.out.println("其他事件，不予捕捉");
                            }
                            System.out.println();
                            // list = [Alice, Bob]
//                            Assert.assertEquals(2, list.size());
                        } catch (ABICodecException | TransactionBaseException e) {
                            logger.error("decode event log error, " + e.getMessage());
                            System.out.println("decode event log error, " + e.getMessage());
                        } catch (TransactionException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        } catch (TimeoutException e) {
                            e.printStackTrace();
                        } catch (ContractException e) {
                            e.printStackTrace();
                        }

                    }
                }
            }
        }

        SubscribeCallback subscribeEventCallback= new SubscribeCallback();
        EventSubscribe eventSubscribe=new EventSubscribeImp( client.getGroupManagerService(), client.getEventResource(), client.getGroupId());

        String registerId=eventSubscribe.subscribeEvent(params1,subscribeEventCallback);

        System.out.println("++++++++++++++++++:"+registerId+"+++++++++++++++++++++++++++");

    }

    // _ledgerSeq represents event.blockNumber
    public void _startTx(String _crossTxNo,BigInteger _crossTxType,BigInteger _ledgerSeq,String _txHash) throws ABICodecException, TransactionBaseException, IOException, TransactionException, InterruptedException, TimeoutException, ContractException {

        System.out.println("Start calling 11111 ==========Please pay attention to check");
        List<Object> params=new ArrayList<>();
        params.add(_crossTxNo);
        // Send transaction synchronously
        TransactionResponse transactionResponse = transactionProcessor.sendTransactionAndGetResponseByContractLoader("CrossChainContract", crossChainContractAddress, "getCrossTx", params);
        // Check if the transaction was successful based on transactionResponse
        System.out.println("Start calling to send the transaction  ==========Please pay attention to it");

        TransactionReceipt transactionReceipt=transactionResponse.getTransactionReceipt();
        String output=transactionReceipt.getOutput();
        // Parse the transaction return value
        ABICodec abiCodec = new ABICodec(client.getCryptoSuite());
        List<Object> list= abiCodec.decodeMethod(abi, "getCrossTx", output);

        System.out.println("====================================");
        System.out.println("Transaction receipt analysis, parsing transactions with return values ==========="+list);
        System.out.println("====================================");

        // Cross-chain basic information: source AC, target AC, source address, target address, cross-chain transaction type
        BasicInfo basicInfo= new BasicInfo();
        // Source chain AC code
        basicInfo.setSrcChainCode(String.valueOf(list.get(0)));
        basicInfo.setDestChainCode(String.valueOf(list.get(1)));
        // Source address
        basicInfo.setSrcBid(String.valueOf(list.get(2)));
        basicInfo.setDestBid(String.valueOf(list.get(3)));
        // Cross-chain transaction type
        basicInfo.setTxType((BigInteger) list.get(4));

        System.out.println("Start displaying basic info ========== Note: Check carefully\n");
        System.out.println(basicInfo.toString());

        // Cross-chain transaction processing status TxResult
        String _txResult= (String) list.get(6);
        String _txRefunded=(String)list.get(7);
        String _txOrigin=(String)list.get(8);

        System.out.println("Start displaying cross-chain transaction processing status ========== Please review\n");
        System.out.println(_txResult);

        // Additional information: remark, extension, version
        ExtensionInfo _extensionInfo = new ExtensionInfo();
        _extensionInfo.setRemark(String.valueOf(list.get(9)));
        _extensionInfo.setExtension(String.valueOf(list.get(10)));
        _extensionInfo.setVersion(String.valueOf(list.get(11)));


        TransactionResponse transactionResponse1 = transactionProcessor.sendTransactionAndGetResponseByContractLoader("CrossChainContract", crossChainContractAddress, "getCrossTxSendAndAckProof", params);
        // Determine if the transaction was successful based on the transactionResponse
        TransactionReceipt transactionReceipt1=transactionResponse1.getTransactionReceipt();
        String output1=transactionReceipt1.getOutput();
        // Parse the transaction return value
        ABICodec abiCodec1 = new ABICodec(client.getCryptoSuite());
        List<Object> list1= abiCodec1.decodeMethod(abi, "getCrossTxSendAndAckProof", output1);
        System.out.println(" Start displaying cross-chain transaction sendProof information ========== Please pay attention\n");
        _SendProof _sendProof=new _SendProof();
        _sendProof.setLedgerSeq((Integer) list1.get(0));
        _sendProof.setTxHash((String) list1.get(1));
        _sendProof.setVerifieraddr((String) list1.get(2));

        _AckProof _ackProof=new _AckProof();
        _ackProof.setLedgerSeq((Integer) list1.get(3));
        _ackProof.setTxHash((String) list1.get(4));
        _ackProof.setVerifieraddr((String) list1.get(5));


        // startTX transaction is in the init unprocessed status

        if(_txResult.equals("INIT")){
            // Build sendTx for the main chain gateway node
            if(_crossTxType.equals(0)){
                // Main chain points transfer; at this time, the payload type is an integer representing the transfer amount
                int  payload= (int) list.get(5);
                System.out.println("===============Main chain points transfer amount："+payload);
            }
            else if(_crossTxType.equals(1)){
                // Sub-chain points exchange
                // Parse payload

               // Send to the other party for cross-chain

            }
            else if(_crossTxType.equals(2)){
                // Send to the other party for cross-chain

                // Contract interoperability: data interaction
                // Parse payload and the destination chain code location


                _CrossTxObj _crossTxObj=new _CrossTxObj();
                _crossTxObj.setCrossTxNo(_crossTxNo);
                _crossTxObj.setSrcChainCode(basicInfo.getSrcChainCode());
                _crossTxObj.setDestChainCode(basicInfo.getDestChainCode());
                _crossTxObj.setSrcBid(basicInfo.getSrcBid());
                _crossTxObj.setDestBid(basicInfo.getDestBid());
                _crossTxObj.setTxType(basicInfo.getTxType().intValue());

                // Parse payload[]
//                _crossTxObj.setPayload();

                _crossTxObj.setRemark(_extensionInfo.getRemark());
                _crossTxObj.setTxResult(_txResult);
                _crossTxObj.setTxRefunded(_txRefunded);
                _crossTxObj.setExtension(_extensionInfo.getExtension());
                _crossTxObj.setSendProofs(_sendProof);
                _crossTxObj.setAckProofs(_ackProof);
                _crossTxObj.setVersion(_extensionInfo.getVersion());
                _crossTxObj.setTxOrigin(_txOrigin);

                CrossChainObj crossChainObj=hubCrossChainGateway.fiscoCrossChainObjToFbaricCrossChaonObj(_crossTxObj);

                // Call another hub to retrieve ledger data
                byte[] proof = new String("proof").getBytes(StandardCharsets.UTF_8);
                String value=hubCrossChainGateway.call(crossChainObj,crossChainObj.getTxResult(),crossChainObj.getVersion(),proof);
                logger.info("The result obtained after the cross-chain call is："+value);
                // Return value from calling one's own contract



            }
        }





        // Call the contract query interface
// CrossChainContract function "name", contract address is helloWorldAddress, with no parameters

//        CallResponse callResponse = transactionProcessor.sendCallByContractLoader("CrossChainContract", crossChainContractAddress, "", new ArrayList<>());
//        String values=callResponse.getValues();




        //
    }
    public void _sendTx(String _crossTxNo,BigInteger _ledgerSeq,String _txHash){

    }
    public void _sendAcked(String _crossTxNo,BigInteger _ledgerSeq,String  _txHash){
        // Call your own cross-chain contract


    }


}
