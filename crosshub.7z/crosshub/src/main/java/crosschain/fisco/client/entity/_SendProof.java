//class encapsulates the details of a cross-chain transaction's proof,
// including ledger sequence, transaction hash, and verifier address.
package crosschain.fisco.client.entity;

public class _SendProof {
    int LedgerSeq;
    String TxHash;
    String verifieraddr;



    public int getLedgerSeq() {
        return LedgerSeq;
    }

    public void setLedgerSeq(int ledgerSeq) {
        LedgerSeq = ledgerSeq;
    }

    public String getTxHash() {
        return TxHash;
    }

    public void setTxHash(String txHash) {
        TxHash = txHash;
    }

    public String getVerifieraddr() {
        return verifieraddr;
    }

    public void setVerifieraddr(String verifieraddr) {
        this.verifieraddr = verifieraddr;
    }
}
