package crosschain.fisco.client;

public class CrossChainContractAdditionalClient {
}
