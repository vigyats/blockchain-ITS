package crosschain.fisco.client.entity;

public enum TxResultEnum {
        INIT,
        ACK_SUCCESS,
        ACK_FAIL,
        ACK_TIMEOUT
}
