package crosschain.fisco.client.entity;

public enum TxOriginEnum {
    SRC,
    DEST,
    RELAY
}
