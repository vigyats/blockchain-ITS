package crosschain.fisco.client.entity;

public enum TxRefundedEnum {
    NONE,
    TODO,
    REFUNDED
}
