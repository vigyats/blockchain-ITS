//The ExtensionInfo class encapsulates additional metadata related to cross-chain transactions,
// including remarks, extension details, and version information.
package crosschain.fisco.client.entity;

//Represents additional information for cross-chain transactions, including remarks, extensions, and version.
public class ExtensionInfo {
   private String  Remark;
   private String  Extension;
   private  String Version;

   //// Default constructor
    public ExtensionInfo() {
    }

     // Parameterized constructor for initializing ExtensionInfo with specific values
    public ExtensionInfo(String remark, String extension, String version) {
        Remark = remark;
        Extension = extension;
        Version = version;
    }

    // Getter for Remark
    public String getRemark() {
        return Remark;
    }
    // Setter for Remark
    public void setRemark(String remark) {
        Remark = remark;
    }
    // Getter for Extension
    public String getExtension() {
        return Extension;
    }
    // Setter for Extension
    public void setExtension(String extension) {
        Extension = extension;
    }
    // Getter for Version
    public String getVersion() {
        return Version;
    }
    // Setter for Version
    public void setVersion(String version) {
        Version = version;
    }

    @Override
    public String toString() {
        return "ExtensionInfo{" +
                "Remark='" + Remark + '\'' +
                ", Extension='" + Extension + '\'' +
                ", Version='" + Version + '\'' +
                '}';
    }

}
