//Provides methods to establish a connection to a Fabric network gateway,
// retrieve a network channel, and access a contract.
package crosschain.fabric.gateway_connect;

import org.hyperledger.fabric.gateway.*;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Connect {
    private static String channelName="mychannel";


    /**
     * connect gateway
     */
    public Gateway connectGateway() throws IOException {

        // Load an existing wallet with user identity for accessing the Fabric network.
        Path walletDirectory = Paths.get("wallet");
        Wallet wallet = Wallets.newFileSystemWallet(walletDirectory);

        //Path to the configuration file for the Fabric network.
        Path networkConfigFile = Paths.get("src/main/resources/connection1.json");

        // Configure the gateway connection to access the Fabric network (user and network configuration files).
        Gateway.Builder builder = Gateway.createBuilder()
                .identity(wallet, "user1")
                .networkConfig(networkConfigFile);

        // Create a gateway connection.
//        try (Gateway gateway = builder.connect()) {
        Gateway gateway = builder.connect();

        return gateway;
    }

    //Get the channel
    public Network getNetwork(Gateway gateway) {
        return gateway.getNetwork(this.channelName);
    }

    //Get the contract
    public Contract getContract(Network network,String contractName) {
        return network.getContract(contractName);
    }
}
