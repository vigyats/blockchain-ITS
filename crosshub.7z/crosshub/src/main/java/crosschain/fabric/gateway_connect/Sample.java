//The code demonstrates how to configure and establish a connection to a Hyperledger Fabric network,
// obtain a channel network, retrieve a smart contract,
// and includes commented-out sections for submitting a transaction and querying the ledger.

package crosschain.fabric.gateway_connect;

import org.hyperledger.fabric.gateway.*;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

class Sample {
    public static void main(String[] args) throws IOException {

        //Load an existing wallet with user credentials for accessing the Fabric network.
        Path walletDirectory = Paths.get("wallet");
        Wallet wallet = Wallets.newFileSystemWallet(walletDirectory);

        //Path is the path to the Fabric network configuration file.
        Path networkConfigFile = Paths.get("src/main/resources/connection1.json");

//        wallet.put("user1",,);
        // Configure the gateway connection for accessing the Fabric network (user and network configuration files).
        Gateway.Builder builder = Gateway.createBuilder()
                .identity(wallet, "user1")
                .networkConfig(networkConfigFile);

        // Create a gateway connection.
//        try (Gateway gateway = builder.connect()) {
            Gateway gateway = builder.connect();
            //Obtain the specified channel network from the gateway.
            Network network = gateway.getNetwork("mychannel");
            //Retrieve the smart contract from the channel network based on the chaincode name.
            Contract contract = network.getContract("fabcar");
             System.out.println(network.toString());

//            // Submit the transaction to store it in the ledger.
//            byte[] createCarResult = contract.createTransaction("createCar")
//                    .submit("CAR10", "VW", "Polo", "Grey", "Mary");
//            System.out.println(new String(createCarResult, StandardCharsets.UTF_8));
//
//            // Query the state from the ledger.
//            byte[] queryAllCarsResult = contract.eval("queryAllCars");
//            System.out.println(new String(queryAllCarsResult, StandardCharsets.UTF_8));

//        } catch (ContractException | TimeoutException | InterruptedException e) {
//            e.printStackTrace();
//        }
    }
}
